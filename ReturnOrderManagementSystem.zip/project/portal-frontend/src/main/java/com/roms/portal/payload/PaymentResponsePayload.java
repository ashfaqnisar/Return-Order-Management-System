package com.roms.portal.payload;

import lombok.Data;

@Data
public class PaymentResponsePayload {
    double currentBalance;
}
