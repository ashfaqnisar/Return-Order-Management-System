package com.roms.packagingdelivery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PackagingDeliveryServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
