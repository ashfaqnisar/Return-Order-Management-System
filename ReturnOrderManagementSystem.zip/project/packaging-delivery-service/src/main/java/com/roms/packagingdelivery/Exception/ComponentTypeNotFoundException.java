package com.roms.packagingdelivery.Exception;

public class ComponentTypeNotFoundException extends RuntimeException {
	public ComponentTypeNotFoundException(String msg)
	{
		super(msg);
	}
}
