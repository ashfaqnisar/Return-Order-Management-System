package com.roms.authentication.exception;

public class InvalidLoginException extends Exception {
	public InvalidLoginException(String msg)
	{
		super(msg);
	}
}
