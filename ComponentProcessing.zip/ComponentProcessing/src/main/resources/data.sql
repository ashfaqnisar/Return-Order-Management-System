insert into process_request values (1, 'Earphones', 'accessory', 1234567890, 9766875311, true, 1, 'Mrunal');
insert into process_request values (2, 'Charger', 'accessory', 1234567890, 9766875311, false, 2, 'Abhishek');
insert into process_request values (3, 'Mobile', 'integral', 1234567890, 9766875311, true, 3, 'Satyam');
insert into process_request values (4, 'Laptop', 'integral', 1234567890, 9766875311, false, 1, 'Harivivek');
