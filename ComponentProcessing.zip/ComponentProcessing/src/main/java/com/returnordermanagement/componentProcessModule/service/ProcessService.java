package com.returnordermanagement.componentProcessModule.service;

import com.returnordermanag.componentProcessModule.model.ProcessResponse;

public interface ProcessService {
	ProcessResponse processDetail(int userID);
}
