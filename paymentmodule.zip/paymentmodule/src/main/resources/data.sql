insert into Credit_Card values (1234567891234567,10000);
insert into Credit_Card values (2345678912345678,20000);
insert into Credit_Card values (5685312579977435,30000);
insert into Credit_Card values (6853289863234678,20000);
insert into Credit_Card values (8964215667889876,20000);