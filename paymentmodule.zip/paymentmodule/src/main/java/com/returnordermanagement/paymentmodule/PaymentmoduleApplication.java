package com.returnordermanagement.paymentmodule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentmoduleApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentmoduleApplication.class, args);
	}

}
